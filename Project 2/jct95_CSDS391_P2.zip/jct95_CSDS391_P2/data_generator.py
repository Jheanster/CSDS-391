
import csv
import numpy as np


def iris_data_generator(data_path, full=False):
    iris_data_file = open(data_path)
    iris_reader = csv.reader(iris_data_file)
    # iris_data = list(iris_reader)

    sepal_l = []
    sepal_w = []
    petal_len = []
    petal_w = []
    species = []

    for row in iris_reader:
        if iris_reader.line_num != 1:
            if not full:
                if row[4] != "setosa":  # if full is not specified as true, exclude Setosa
                    sepal_l.append(float(row[0]))
                    sepal_w.append(float(row[1]))
                    petal_len.append(float(row[2]))
                    petal_w.append(float(row[3]))
                    species.append(row[4])
            else:
                sepal_l.append(float(row[0]))
                sepal_w.append(float(row[1]))
                petal_len.append(float(row[2]))
                petal_w.append(float(row[3]))
                species.append(row[4])

    return sepal_l, sepal_w, petal_len, petal_w, species


def create_data_vectors(*args):
    if len(args) == 2:
        x_1 = args[0]
        x_2 = args[1]
        X = np.zeros((2, len(x_1)))
        for i in range(len(x_1)):
            X[0, i] = x_1[i]
            X[1, i] = x_2[i]
    elif len(args) == 4:
        x_1 = args[0]
        x_2 = args[1]
        x_3 = args[2]
        x_4 = args[3]
        X = np.zeros((4, len(x_1)))
        for i in range(len(x_1)):
            X[0, i] = x_1[i]
            X[1, i] = x_2[i]
            X[2, i] = x_3[i]
            X[3, i] = x_4[i]
    return X  # a 2x(length) matrix with columns individual x vectors as columns


def create_augmented_data_vectors(x_1, x_2):
    X_augmented = np.zeros((3, len(x_1)))
    for i in range(len(x_1)):
        X_augmented[0, i] = 1
        X_augmented[1, i] = x_1[i]
        X_augmented[2, i] = x_2[i]
    return X_augmented  # a 2x(length) matrix with columns individual x vectors as columns

# def create_data_vectors(x_one, x_two, x_three, x_four):
